class MyList:
    def __init__(self):
        self.a = []
        self.count = 0
            
    def readArray(self):
        self.count = int(raw_input("Enter count of numbers: "))
        print "Enter numbers: "
        for i in range(self.count):
            self.a.append(int(raw_input()))    
        return self.count  
                  
    def MySort(self):
        self.a.sort()
        
    def Bisearch(self,num,l,h):
        mid = (l+h)/2
        if l<=h :
            if num > self.a[mid]:
                return self.Bisearch(num,mid+1,h)
            elif num==self.a[mid]:
                return True
            elif num < self.a[mid]:
                return self.Bisearch(num,l,mid-1)
                                                   
if __name__=="__main__":
    a = MyList()
    c = a.readArray()
    a.MySort()
    aws = a.Bisearch(int(raw_input("Enter key to be searched")),0,c)
    if aws:
        print "Element found"
    else:
        print "Element not found"
